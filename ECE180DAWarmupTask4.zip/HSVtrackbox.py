import cv2 as cv
import numpy as np

def find_and_draw_contours(frame, lower_color, upper_color, color_for_drawing):
    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    mask = cv.inRange(hsv, lower_color, upper_color)
    contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

    if contours:
        largest_contour = max(contours, key=cv.contourArea)
        x, y, w, h = cv.boundingRect(largest_contour)
        cv.rectangle(frame, (x, y), (x + w, y + h), color_for_drawing, 2)
    return frame

def main():
    cap = cv.VideoCapture(0)

    lower_blue = np.array([110,50,50])
    upper_blue = np.array([130,255,255])
    rect_color = (0, 255, 0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        processed_frame = find_and_draw_contours(frame, lower_blue, upper_blue, rect_color)
        cv.imshow('Processed Frame', processed_frame)

        if cv.waitKey(5) & 0xFF == 27:
            break

    cap.release()
    cv.destroyAllWindows()

if __name__ == "__main__":
    main()
