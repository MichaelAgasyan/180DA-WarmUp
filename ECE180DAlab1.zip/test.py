if __name__ == '__main__':
    x = "ECE_180_DA_DB"
    if x == "EE_180_DA_DB":
        print("You are living in 2017")
    else:
        x = x + " - Best class ever"
        print(x)